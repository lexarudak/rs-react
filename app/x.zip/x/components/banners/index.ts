import OuterBanner from './OuterBanner/OuterBanner';
import InnerBanner from './InnerBanner/InnerBanner';

export { OuterBanner, InnerBanner };
