import BigCard from './BigCard/BigCard';
import BigCardInfoList from './BigCard/BigCardInfoList/BigCardInfoList';
import MainCard from './MainCard/MainCard';
import FormCard from './FormCard/FormCard';

export { BigCard, BigCardInfoList, MainCard, FormCard };
